# config_override.py

configs = {
    'db': {
        'host': '127.0.0.1',
        'user': 'www-data',
        'password': 'www-data',
    }
}